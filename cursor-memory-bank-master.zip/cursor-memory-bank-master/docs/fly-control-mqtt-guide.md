Title: 指令飞行 | Cloud API

URL Source: https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E5%9B%BE%E4%BC%A0%E6%89%93%E7%82%B9%E7%BB%93%E6%9E%9C%E4%BA%8B%E4%BB%B6%E9%80%9A%E7%9F%A5

Published Time: Wed, 10 Dec 2025 12:02:41 GMT

Markdown Content:
指令飞行
----

Event[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#event "Event的直接链接")
-------------------------------------------------------------------------------------------

flyto 执行结果事件通知[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#flyto-%E6%89%A7%E8%A1%8C%E7%BB%93%E6%9E%9C%E4%BA%8B%E4%BB%B6%E9%80%9A%E7%9F%A5 "flyto 执行结果事件通知的直接链接")
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/events

**Direction:** up

**Method:** fly_to_point_progress

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| fly_to_id | 飞向目标点 ID | text |  |  |
| status | 状态 | enum_string | {"wayline_cancel":"取消飞向目标点","wayline_failed":"执行失败","wayline_ok":"执行成功，已飞向目标点","wayline_progress":"执行中"} |  |
| result | 返回码 | int |  | 非 0 代表错误 |
| way_point_index | 当前执行到第几个航点 | int |  |  |
| remaining_distance | 剩余任务距离 | float | {"step":0.1,"unit_name":"米 / m"} |  |
| remaining_time | 剩余任务时间 | float | {"step":0.1,"unit_name":"秒 / s"} |  |
| planned_path_points | 规划的轨迹点列表 | array | {"size": -, "item_type": struct} |  |
| »latitude | 轨迹点纬度(角度值) | double | {"max":90,"min":-90} | 轨迹点纬度，角度值，南纬是负，北纬是正，精度到小数点后6位 |
| »longitude | 轨迹点经度(角度值) | double | {"max":180,"min":-180} | 轨迹点经度，角度值，东经是正，西经是负，精度到小数点后6位 |
| »height | 轨迹点高度 | float | {"step":0.1,"unit_name":"米 / m"} | 轨迹点高度,椭球高 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"fly_to_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",		"planned_path_points": [			{				"height": 123.234,				"latitude": 13.23,				"longitude": 123.234			}		],		"remaining_distance": 0,		"remaining_time": 0,		"result": 0,		"status": "wayline_progress",		"way_point_index": 0	},	"need_reply": 1,	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 16540709686556,	"method": "fly_to_point_progress"}`

一键起飞结果事件通知[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E4%B8%80%E9%94%AE%E8%B5%B7%E9%A3%9E%E7%BB%93%E6%9E%9C%E4%BA%8B%E4%BB%B6%E9%80%9A%E7%9F%A5 "一键起飞结果事件通知的直接链接")
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/events

**Direction:** up

**Method:** takeoff_to_point_progress

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| status | 任务状态 | enum_string | {"task_finish":"一键起飞任务完成","task_ready":"准备起飞","wayline_cancel":"取消飞向目标点","wayline_failed":"执行失败","wayline_ok":"执行成功，已飞向目标点","wayline_progress":"执行中"} |  |
| result | 返回码 | int |  | 非 0 代表错误 |
| flight_id | 一键起飞任务 UUID | text |  |  |
| track_id | 航迹 ID | text |  |  |
| way_point_index | 当前执行到第几个航点 | int |  |  |
| remaining_distance | 剩余任务距离 | float | {"step":0.1,"unit_name":"米 / m"} |  |
| remaining_time | 剩余任务时间 | float | {"step":0.1,"unit_name":"秒 / s"} |  |
| planned_path_points | 规划的轨迹点列表 | array | {"size": -, "item_type": struct} |  |
| »latitude | 轨迹点纬度(角度值) | double | {"max":90,"min":-90} | 轨迹点纬度，角度值，南纬是负，北纬是正，精度到小数点后6位 |
| »longitude | 轨迹点经度(角度值) | double | {"max":180,"min":-180} | 轨迹点经度，角度值，东经是正，西经是负，精度到小数点后6位 |
| »height | 轨迹点高度 | float | {"step":0.1,"unit_name":"米 / m"} | 轨迹点高度,椭球高 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"flight_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",		"planned_path_points": [			{				"height": 123.234,				"latitude": 13.23,				"longitude": 123.234			}		],		"remaining_distance": 0,		"remaining_time": 0,		"result": 0,		"status": "wayline_ok",		"track_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",		"way_point_index": 1	},	"need_reply": 1,	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 16540709686556,	"method": "takeoff_to_point_progress"}`

飞行控制权抢夺[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E9%A3%9E%E8%A1%8C%E6%8E%A7%E5%88%B6%E6%9D%83%E6%8A%A2%E5%A4%BA "飞行控制权抢夺的直接链接")
---------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** flight_authority_grab

**Data:** null

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "flight_authority_grab"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** flight_authority_grab

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "flight_authority_grab"}`

负载控制权抢夺[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E8%B4%9F%E8%BD%BD%E6%8E%A7%E5%88%B6%E6%9D%83%E6%8A%A2%E5%A4%BA "负载控制权抢夺的直接链接")
---------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** payload_authority_grab

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| payload_index | 负载枚举值 | text |  | 镜头负载与挂载位置枚举值。非标准的 device_mode_key，格式为 {type-subtype-gimbalindex}，可以参考产品支持页面 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"payload_index": "68-0-0"	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "payload_authority_grab"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** payload_authority_grab

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "payload_authority_grab"}`

进入指令飞行控制模式[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E8%BF%9B%E5%85%A5%E6%8C%87%E4%BB%A4%E9%A3%9E%E8%A1%8C%E6%8E%A7%E5%88%B6%E6%A8%A1%E5%BC%8F "进入指令飞行控制模式的直接链接")
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** drc_mode_enter

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| mqtt_broker | Broker 连接信息 | struct |  | 获取 MQTT 中继服务的地址与认证信息 |
| »address | 服务器连接地址 | text |  | 服务器连接地址，例如：192.0.2.1:8883, mqtt.autel.com:8883 |
| »client_id | 客户端 ID | text |  | 可自定义的 MQTT 客户端 ID。建议使用设备的SN码的前缀组合，例如，drc-TH12345678，不建议直接使用设备SN码，避免同一个MQTT互相挤下线 |
| »username | 用户名 | text |  | 建立连接时使用的用户名 |
| »password | 密码 | text |  | 建立连接时认证所需要的密码 |
| »expire_time | 认证信息过期时间 | int | {"unit_name":"秒 / s"} | 在有效期内认证信息可以重复使用，另外认证信息过期后，并不会影响已建立连接的设备 |
| »enable_tls | 是否启用 TLS | bool |  | 启用 TLS 即对 MQTT 链路开启加密 |
| osd_frequency | OSD 频率 | int | {"max":30,"min":1,"unit_name":"赫兹 / Hz"} | 设置 OSD 上报频率 |
| hsi_frequency | HSI 频率 | int | {"max":30,"min":1,"unit_name":"赫兹 / Hz"} | 设置 HSI 上报频率 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"hsi_frequency": 1,		"mqtt_broker": {			"address": "mqtt.autel.com:8883",			"client_id": "sn_a",			"enable_tls": true,			"expire_time": 1672744922,			"password": "jwt_token",			"username": "sn_a_username"		},		"osd_frequency": 10	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "drc_mode_enter"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** drc_mode_enter

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "drc_mode_enter"}`

退出指令飞行控制模式[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E9%80%80%E5%87%BA%E6%8C%87%E4%BB%A4%E9%A3%9E%E8%A1%8C%E6%8E%A7%E5%88%B6%E6%A8%A1%E5%BC%8F "退出指令飞行控制模式的直接链接")
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** drc_mode_exit

**Data:** null

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "drc_mode_exit"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** drc_mode_exit

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "drc_mode_exit"}`

一键起飞[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E4%B8%80%E9%94%AE%E8%B5%B7%E9%A3%9E "一键起飞的直接链接")
------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** takeoff_to_point

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| target_latitude | 目标点纬度(角度值) | double | {"max":90,"min":-90} | 目标点纬度，角度值，南纬是负，北纬是正，精度到小数点后6位 |
| target_longitude | 目标点经度(角度值) | double | {"max":180,"min":-180} | 目标点经度，角度值，东经是正，西经是负，精度到小数点后6位 |
| target_height | 目标点高度 | float | {"max":1500,"min":2,"step":0.1,"unit_name":"米 / m"} | 目标点高度（相对高），无人机到点后默认行为：悬停 |
| flight_id | 一键起飞任务 UUID | text |  | 任务 UUID，全局唯一，用于染色，云端区分该值是普通计划任务还是一键起飞任务 |
| max_speed | 一键起飞的飞行过程中能达到的最大速度 | int | {"max":15,"min":1,"unit_name":"米每秒 / m/s"} |  |

**Example:** 注意一键起飞只能在室外，并且目标经纬度不能离当前经纬度太远

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"flight_id": "ABDEAC21DCADDA",		"max_speed": 12,		"target_height": 100,		"target_latitude": 12.23,		"target_longitude": 12.32	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "takeoff_to_point"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** takeoff_to_point

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "takeoff_to_point"}`

flyto 飞向目标点[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#flyto-%E9%A3%9E%E5%90%91%E7%9B%AE%E6%A0%87%E7%82%B9 "flyto 飞向目标点的直接链接")
-----------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** fly_to_point

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| fly_to_id | 飞向目标点 ID | text |  |  |
| max_speed | flyto 的飞行过程中能达到的最大速度 | int | {"max":15,"min":0,"unit_name":"米每秒 / m/s"} |  |
| points | flyto 目标点列表 | array | {"size": -, "item_type": struct} | 仅支持 1 个目标点 |
| »latitude | 目标点纬度(角度值) | double | {"max":90,"min":-90} | 目标点纬度，角度值，南纬是负，北纬是正，精度到小数点后6位 |
| »longitude | 目标点经度(角度值) | double | {"max":180,"min":-180} | 目标点经度，角度值，东经是正，西经是负，精度到小数点后6位 |
| »height | 目标点高度 | float | {"max":10000,"min":2,"step":0.1,"unit_name":"米 / m"} | 目标点高度（相对高度） |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"fly_to_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",		"max_speed": 12,		"points": [			{				"height": 100,				"latitude": 12.23,				"longitude": 12.23			}		]	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "fly_to_point"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** fly_to_point

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "fly_to_point"}`

结束 flyto 飞向目标点任务[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E7%BB%93%E6%9D%9F-flyto-%E9%A3%9E%E5%90%91%E7%9B%AE%E6%A0%87%E7%82%B9%E4%BB%BB%E5%8A%A1 "结束 flyto 飞向目标点任务的直接链接")
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** fly_to_point_stop

**Data:** null

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "fly_to_point_stop"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** fly_to_point_stop

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "fly_to_point_stop"}`

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"reason": 0	},	"need_reply": 1,	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "joystick_invalid_notify"}`

Joystick 控制无效原因通知[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#joystick-%E6%8E%A7%E5%88%B6%E6%97%A0%E6%95%88%E5%8E%9F%E5%9B%A0%E9%80%9A%E7%9F%A5 "Joystick 控制无效原因通知的直接链接")
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Joystick 是一个无人机综合控制功能，若不可用，则无法使用 drone_control 能力，实现手动操控

**Topic:** thing/product/_{gateway\_sn}_/events

**Direction:** up

**Method:** joystick_invalid_notify

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| reason | 任务状态 | int | {"0":"遥控器失联","1":"低电量返航","2":"低电量降落","3":"靠近限飞区","4":"遥控器夺权（例如：触发了返航，B控夺权）"} |  |

负载控制—单拍[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E8%B4%9F%E8%BD%BD%E6%8E%A7%E5%88%B6%E5%8D%95%E6%8B%8D "负载控制—单拍的直接链接")
------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** camera_photo_take

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| payload_index | 相机枚举 | text |  | 相机枚举值。非标准的 device_mode_key，格式为 {type-subtype-gimbalindex}，可以参考[产品支持] |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"payload_index": "68-0-0"	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "camera_photo_take"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** camera_photo_take

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "camera_photo_take"}`

负载控制—开始录像[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E8%B4%9F%E8%BD%BD%E6%8E%A7%E5%88%B6%E5%BC%80%E5%A7%8B%E5%BD%95%E5%83%8F "负载控制—开始录像的直接链接")
----------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** camera_recording_start

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| payload_index | 相机枚举 | text |  | 相机枚举值。非标准的 device_mode_key，格式为 {type-subtype-gimbalindex}，可以参考[产品支持] |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"payload_index": "68-0-0"	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "camera_recording_start"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** camera_recording_start

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "camera_recording_start"}`

负载控制—停止录像[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E8%B4%9F%E8%BD%BD%E6%8E%A7%E5%88%B6%E5%81%9C%E6%AD%A2%E5%BD%95%E5%83%8F "负载控制—停止录像的直接链接")
----------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** camera_recording_stop

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| payload_index | 相机枚举 | text |  | 相机枚举值。非标准的 device_mode_key，格式为 {type-subtype-gimbalindex}，可以参考[产品支持] |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"payload_index": "68-0-0"	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "camera_recording_stop"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** camera_recording_stop

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "camera_recording_stop"}`

负载控制—画面拖动控制[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E8%B4%9F%E8%BD%BD%E6%8E%A7%E5%88%B6%E7%94%BB%E9%9D%A2%E6%8B%96%E5%8A%A8%E6%8E%A7%E5%88%B6 "负载控制—画面拖动控制的直接链接")
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** camera_screen_drag

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| payload_index | 相机枚举 | text |  | 相机枚举值。非标准的 device_mode_key，格式为 {type-subtype-gimbalindex}，可以参考[产品支持] |
| locked | 机头和云台的相对关系是否锁定 | bool | {"false":"仅云台转，机身不转","true":"锁定机头，云台和机身一起转"} |  |
| pitch_speed | 云台 pitch 速度 | double | {"unit_name":"度每秒 / deg/s"} | 云台 pitch 速度，仅支持云台转 |
| yaw_speed | 云台 yaw 速度 | double | {"unit_name":"度每秒 / deg/s"} | 云台 yaw 速度，仅支持锁机头 |
| angle_unit | 速度单位 | int | {为0时，单位弧度; 为1时，单位度} | 非必传，默认为孤度 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"locked": false,		"payload_index": "68-0-0",		"pitch_speed": 0.1,		"yaw_speed": 0.1	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "camera_screen_drag"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** camera_screen_drag

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "camera_screen_drag"}`

负载控制—变焦[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E8%B4%9F%E8%BD%BD%E6%8E%A7%E5%88%B6%E5%8F%98%E7%84%A6 "负载控制—变焦的直接链接")
------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** camera_focal_length_set

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| payload_index | 相机枚举 | text |  | 相机枚举值。非标准的 device_mode_key，格式为 {type-subtype-gimbalindex}，可以参考[产品支持] |
| camera_type | 相机类型 | enum_string | {"ir":"红外","wide":"广角","zoom":"变焦"} | 相机类型枚举 |
| zoom_factor | 变焦倍数 | double | {"max":200,"min":2} | 变焦倍数，可见光是2-200，红外是2-20 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"camera_type": "zoom",		"payload_index": "68-0-0",		"zoom_factor": 5	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "camera_focal_length_set"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** camera_focal_length_set

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "camera_focal_length_set"}`

负载控制—重置云台[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E8%B4%9F%E8%BD%BD%E6%8E%A7%E5%88%B6%E9%87%8D%E7%BD%AE%E4%BA%91%E5%8F%B0 "负载控制—重置云台的直接链接")
----------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** gimbal_reset

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| payload_index | 负载编号 | text |  | 负载编号，相机枚举值。非标准的 device_mode_key，格式为 {type-subtype-gimbalindex}，可以参考[产品支持] |
| reset_mode | 重置模式类型 | enum_int | {"0":"回中","1":"向下","2":"偏航回中","3":"向下45度","101":"向上30度","102":"向上45度","103":"向上90度"} |  |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"payload_index": "68-0-0",		"reset_mode": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "gimbal_reset"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** gimbal_reset

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "gimbal_reset"}`

负载控制—照片存储设置[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E8%B4%9F%E8%BD%BD%E6%8E%A7%E5%88%B6%E7%85%A7%E7%89%87%E5%AD%98%E5%82%A8%E8%AE%BE%E7%BD%AE "负载控制—照片存储设置的直接链接")
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** photo_storage_set

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| payload_index | 相机枚举 | text |  | 相机枚举值。非标准的 device_mode_key，格式为 {type-subtype-gimbalindex}，可以参考[产品支持] |
| photo_storage_settings | 照片存储设置集合 | array | {"size": -, "item_type": enum_string} | 拍照存储类型{current, wide, zoom, ir}，可多选 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"payload_index": "68-0-0",		"photo_storage_settings": [			"current",			"wide",			"zoom",			"ir"		]	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "photo_storage_set"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** photo_storage_set

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "photo_storage_set"}`

负载控制—视频存储设置[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E8%B4%9F%E8%BD%BD%E6%8E%A7%E5%88%B6%E8%A7%86%E9%A2%91%E5%AD%98%E5%82%A8%E8%AE%BE%E7%BD%AE "负载控制—视频存储设置的直接链接")
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** video_storage_set

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| payload_index | 相机枚举 | text |  | 相机枚举值。非标准的 device_mode_key，格式为 {type-subtype-gimbalindex}，可以参考[产品支持] |
| video_storage_settings | 视频存储设置集合 | array | {"size": -, "item_type": enum_string} | 视频存储类型{current, wide, zoom, ir}，可多选 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"payload_index": "68-0-0",		"video_storage_settings": [			"current",			"wide",			"zoom",			"ir"		]	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "video_storage_set"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** video_storage_set

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "video_storage_set"}`

负载控制—Look At[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E8%B4%9F%E8%BD%BD%E6%8E%A7%E5%88%B6look-at "负载控制—Look At的直接链接")
-----------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** camera_look_at

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| latitude | 目标点纬度 | double | {"max":90,"min":-90} | 角度值。南纬是负，北纬是正，精度到小数点后6位。 |
| longitude | 目标点经度 | double | {"max":180,"min":-180} | 角度值。东经是正，西经是负，精度到小数点后6位。 |
| height | 目标点高度 | float | {"max":10000,"min":2,"step":0.1,"unit_name":"米 / m"} | 目标点高度（椭球高） |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"height": 100,		"latitude": 12.23,		"longitude": 12.23	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "camera_look_at"}`

负载控制—云台角度控制[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E8%B4%9F%E8%BD%BD%E6%8E%A7%E5%88%B6%E4%BA%91%E5%8F%B0%E8%A7%92%E5%BA%A6%E6%8E%A7%E5%88%B6 "负载控制—云台角度控制的直接链接")
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** gimbal_rotate_angle

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| payload_index | 相机枚举 | text |  | 相机枚举值。非标准的 device_mode_key，格式为 {type-subtype-gimbalindex}，可以参考[产品支持] |
| pitch_angle | 俯仰角度 | double | {"max":30,"min":-90,"unit_name":"度/ deg"} | 云台俯仰角度，-90度代表向下，30度代表向上 |

**Example:**

`\{    "bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "data": \{        "payload_index": "68-0-0",        "pitch_angle": -45.0,    \},    "tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "timestamp": 1654070968655,    "method": "gimbal_rotate_angle"\}`

**Topic:** thing/product/{gateway_sn}/services_reply

**Direction:** up

**Method:** gimbal_rotate_angle

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

图传打点结果事件通知[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E5%9B%BE%E4%BC%A0%E6%89%93%E7%82%B9%E7%BB%93%E6%9E%9C%E4%BA%8B%E4%BB%B6%E9%80%9A%E7%9F%A5 "图传打点结果事件通知的直接链接")
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/events

**Direction:** up

**Method:** intelligent_point

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| req_id | 请求ID | int |  | 请求id，和打点时传入的请求id保持一致 |
| status | 打点结果 | int | 0:失败 1:成功 |  |
| latitude | 纬度 | double |  | 精度:10e-7 |
| longitude | 经度 | double |  | 精度:10e-7 |
| altitude | 相对高度 | double |  |  |

图传打点[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#%E5%9B%BE%E4%BC%A0%E6%89%93%E7%82%B9 "图传打点的直接链接")
------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** intelligent_point

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| x | x坐标 | double | {"max":1.0,"min":0"} | 选点在视频画面中的比例，中心点为0.5 |
| y | y坐标 | double | {"max":1.0,"min":0"} | 选点在视频画面中的比例，中心点为0.5 |
| width | 视频分辨率宽 | int |  |  |
| height | 视频分辨率高 | int |  |  |
| lens_type | 镜头类型 | int | 0：可见光，1：红外，2：夜视，3：广角 |  |
| req_id | 请求ID | int |  | 连续的图传打点req_id不能相同 |

**Example:**

`{    "bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "data": {        "x": 0.5,        "y": 0.5,        "width": 1920,        "height": 1080,        "lens_type": 0,        "req_id": 1    },    "tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "timestamp": 1654070968655,    "method": "intelligent_point"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** intelligent_point

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{    "bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "data": {        "result": 0    },    "tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "timestamp": 1654070968655,    "method": "intelligent_point"}`

DRC
---

DRC-飞行控制[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#drc-%E9%A3%9E%E8%A1%8C%E6%8E%A7%E5%88%B6 "DRC-飞行控制的直接链接")
------------------------------------------------------------------------------------------------------------------------------------

进入指令飞行模式后允许通过该指令控制无人机航行方向与速度，发送的频率需要保持在**5-10hz**以内让设备能够比较精准的控制速度变化与方向。同时，需要保证飞机已经处于打桨飞行的状态，要不会无效。

**Topic:** thing/product/_{gateway\_sn}_/drc/down

**Direction:** down

**Method:** drone_control

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| seq | 命令序号 | int |  | 递增的序号，保证指令顺序执行。若 x、y、h、w 参数发生变化，seq 需要从 0 开始增长。 |
| x | 前进后退方向的速度 | double | {"max":17,"min":-17,"unit_name":"米每秒 / m/s"} | 前进后退的最大速度，负值表示向后移动 |
| y | 左右方向的速度 | double | {"max":17,"min":-17,"unit_name":"米每秒 / m/s"} | 左右移动的最大速度，负值表示向左移动 |
| h | 上下方向的速度 | double | {"max":5,"min":-4,"unit_name":"米每秒 / m/s"} | 向上向下移动的最大速度，负值表示向下移动 |
| w | 机身角速度 | double | {"max":90,"min":-90,"unit_name":"弧度每秒 / rad/s"} | 顺时针与逆时针的最大角速度，负值表示逆时针转动 |

**Example:**

`{	"data": {		"freq": 10,		"h": 2.76,		"seq": 1,		"w": 2.86,		"x": 2.34,		"y": -2.45	},	"method": "drone_control"}`

**Topic:** thing/product/_{gateway\_sn}_/drc/up

**Direction:** up

**Method:** drone_control

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误，异常case：没有飞行控制权，没有虚拟摇杆权限，数据包序号不对 |
| output | 输出 | struct |  |  |
| »seq | 命令序号 | int |  | 递增的序号，保证指令顺序执行 |

**Example:**

`{	"data": {		"output": {			"seq": 1		},		"result": 0	},	"method": "drone_control"}`

DRC-无人机急停[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#drc-%E6%97%A0%E4%BA%BA%E6%9C%BA%E6%80%A5%E5%81%9C "DRC-无人机急停的直接链接")
-----------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/drc/down

**Direction:** down

**Method:** drone_emergency_stop

**Data:** null

**Example:**

`{	"data": {},	"method": "drone_emergency_stop"}`

**Topic:** thing/product/_{gateway\_sn}_/drc/up

**Direction:** up

**Method:** drone_emergency_stop

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"data": {		"result": 0	},	"method": "drone_emergency_stop"}`

DRC-心跳[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#drc-%E5%BF%83%E8%B7%B3 "DRC-心跳的直接链接")
--------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/drc/down

**Direction:** down

**Method:** heart_beat

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| seq | 命令序号 | int |  | 递增的序号，保证指令顺序执行 |
| timestamp | 心跳发送时间戳 | int | {"unit_name":"毫秒 / ms"} | 收到的心跳发送时的时间戳，非设备端的时间，便于云端根据收发的间隔做时延计算 |

**Example:**

`{	"data": {		"seq": 10,		"timestamp": 1670415891013	},	"method": "heart_beat"}`

**Topic:** thing/product/_{gateway\_sn}_/drc/up

**Direction:** up

**Method:** heart_beat

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| seq | 命令序号 | int |  | 递增的序号，保证指令顺序执行 |
| timestamp | 心跳发送时间戳 | int | {"unit_name":"毫秒 / ms"} | 收到的心跳发送时的时间戳，非设备端的时间，便于云端根据收发的间隔做时延计算 |

**Example:**

`{	"data": {		"seq": 10,		"timestamp": 1670415891013	},	"method": "heart_beat"}`

DRC-避障信息上报[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/110#drc-%E9%81%BF%E9%9A%9C%E4%BF%A1%E6%81%AF%E4%B8%8A%E6%8A%A5 "DRC-避障信息上报的直接链接")
----------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/drc/up

**Direction:** up

**Method:** hsi_info_push

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| down_distance | 下方障碍物距离 | int | 单位：毫米 |  |
| up_distance | 上方障碍物距离 | int | 单位：毫米 |  |
| front1_distance | 前方1号雷达障碍物距离 | int | 单位：毫米 |  |
| front2_distance | 前方2号雷达障碍物距离 | int | 单位：毫米 |  |
| front3_distance | 前方3号雷达障碍物距离 | int | 单位：毫米 |  |
| front4_distance | 前方4号雷达障碍物距离 | int | 单位：毫米 |  |
| left1_distance | 左侧1号雷达障碍物距离 | int | 单位：毫米 |  |
| left2_distance | 左侧2号雷达障碍物距离 | int | 单位：毫米 |  |
| left3_distance | 左侧3号雷达障碍物距离 | int | 单位：毫米 |  |
| rear1_distance | 后方1号雷达障碍物距离 | int | 单位：毫米 |  |
| rear2_distance | 后方2号雷达障碍物距离 | int | 单位：毫米 |  |
| rear3_distance | 后方3号雷达障碍物距离 | int | 单位：毫米 |  |
| rear4_distance | 后方4号雷达障碍物距离 | int | 单位：毫米 |  |
| right1_distance | 右侧1号雷达障碍物距离 | int | 单位：毫米 |  |
| right2_distance | 右侧2号雷达障碍物距离 | int | 单位：毫米 |  |
| right3_distance | 右侧3号雷达障碍物距离 | int | 单位：毫米 |  |
| radar_enable | 避障开关 | boolean |  |  |

**Example:**

`{  "bid":"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",  "data":{    "down_distance":0,    "front1_distance":0,    "front2_distance":0,    "front3_distance":0,    "front4_distance":0,    "left1_distance":0,    "left2_distance":0,    "left3_distance":0,    "radar_enable":true,    "rear1_distance":0,    "rear2_distance":0,    "rear3_distance":0,    "rear4_distance":0,    "right1_distance":0,    "right2_distance":0,    "right3_distance":0,    "up_distance":0  },  "tid":"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",  "timestamp":1726131014572,  "method":"hsi_info_push"}`

开启目标识别[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/120#%E5%BC%80%E5%90%AF%E7%9B%AE%E6%A0%87%E8%AF%86%E5%88%AB "开启目标识别的直接链接")
----------------------------------------------------------------------------------------------------------------------------------------------

先执行target_detect_open -》 再执行select_tracking_target 目标锁定

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** target_detect_open

**Data:**

| **Column** | **Name** | **Type** | **constraint** | **Description** |
| --- | --- | --- | --- | --- |
| ai_lens_type | 检测镜头 | int | 0：可见光，1：红外，2：夜视（暂不支持） |  |
| scene_type | 当前识别场景 | int | 0：通用 | 默认传0 |
| target_type_list | 当前用户选择的检测类型列表，列表传空，表示当前识别场景下的所有支持检测类型进识别 | list`<int>` | 见下文“目标识别类型”定义 | 可以传NULL |

**Example****：**

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** target_detect_open

| **Column** | **Name** | **Type** | **constraint** | **Description** |
| --- | --- | --- | --- | --- |
| result | 是否打开AI识别 | int |  | 0成功 非0失败 |

关闭目标识别[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/120#%E5%85%B3%E9%97%AD%E7%9B%AE%E6%A0%87%E8%AF%86%E5%88%AB "关闭目标识别的直接链接")
----------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** target_detect_close

**Data:**

**Example****：**

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** target_detect_close

| **Column** | **Name** | **Type** | **constraint** | **Description** |
| --- | --- | --- | --- | --- |
| result | 关闭AI识别操作结果 | int |  | 0成功 非0失败 |

选择锁定目标的信息[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/120#%E9%80%89%E6%8B%A9%E9%94%81%E5%AE%9A%E7%9B%AE%E6%A0%87%E7%9A%84%E4%BF%A1%E6%81%AF "选择锁定目标的信息的直接链接")
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

锁定目标功能指飞行器将原地调整机身正对着该目标，该目标点将成为镜头视野的中心。

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** select_tracking_target

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| locked | 机头和云台的相对关系是否锁定 | bool | false:仅云台转，机身不转, true:锁定机头，云台和机身一起转 |  |
| start_x | 起始点x坐标 | double |  |  |
| start_y | 起始点y坐标 | double |  |  |
| width | 目标点宽度 | double |  |  |
| height | 目标点高度 | double |  |  |
| tracker_id | 检测目标ID | int |  |  |

**Example:**

`{    "bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "data": {        "start_x": 0.5,        "start_y": 0.5,        "locked": true,        "width": 0.8,        "height": 0.3,        "tracker_id": 123456    },    "tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "timestamp": 1654070968655,    "method": "select_tracking_target"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** select_tracking_target

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{    "bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "data": {        "result": 0    },    "tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "timestamp": 1654070968655,    "method": "select_tracking_target"}`

退出目标锁定[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/120#%E9%80%80%E5%87%BA%E7%9B%AE%E6%A0%87%E9%94%81%E5%AE%9A "退出目标锁定的直接链接")
----------------------------------------------------------------------------------------------------------------------------------------------

退出目标锁定，还会继续目标检测，关闭目标识别才会不再检测目标。

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** target_tracking_close

**Data:**

**Example：**

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** target_tracking_close

| **Column** | **Name** | **Type** | **constraint** | **Description** |
| --- | --- | --- | --- | --- |
| result | 关闭AI识别操作结果 | int |  | 0成功 非0失败 |

开始直播[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/30#%E5%BC%80%E5%A7%8B%E7%9B%B4%E6%92%AD "开始直播的直接链接")
-----------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** live_start_push

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| url_type | 直播协议类型 | enum | {"1":"RTMP","2":"RTSP","3":"GB28181"\，"4":"WHIP} |  |
| url | 直播参数 | text | {} | RTMP: (rtmp://xxxxxxx)示例：rtmp://192.168.1.1:8080/live |
| video_id | 直播视频流的ID编号 | text | {} | 格式为 #{uav_sn}/#{camera_id}/#{video_index};无人机SN号/负载及挂载位置枚举值/负载lens编号 比如机巢推流ID"1748FEV3HMA923171787/nest-camera-out/normal"， 无人机推流ID "1748FEV3HMA923171787/{camera_id}/normal" 设备会对下发的地址中 camera_id 进行校验，camera_id 需要从直播能力集中的 camera_index获取 |
| video_quality | 直播质量 | enum | {"2":"标清","3":"高清} | 不同清晰度的分辨率为，标清：1280 * 720，超清：1920 * 1080 |
| video_type | 直播镜头 | text | {"normal","zoom","ir"} | 不同的镜头类型，比如普通/变焦/红外 |
| intranet_url | 内网地址 | text |  | 4G增强图传必填，其他不用填 ，内网服务器地址 |
| external_url | 外网地址 | text |  | 4G增强图传必填，其他不用填 ，外网服务器地址。可以和 intranet_url一样。 |
| token | 鉴权字符串 | text |  | 4G增强图传使用，必填 |

**Example:**

`{    "timestamp": 1711022516332,    "data": {        "url": "rtmp://test-mediacenter.autelrobotics.cn:1936/live/1748FEV3HMA923171787/drone-camera-0/normal",        "url_type": 1,        "video_id": "1748FEV3HMA923171787/10802-0-0/normal",        "video_quality": 1,        "video_type": "zoom"    },    "method": "live_start_push",    "tid": "b92a6aa1-96eb-4b4a-848f-c0f63f206d3b",    "bid": "74008969-0d46-4f69-9a03-78423824fe24",    "gateway": "TH7923221094"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** live_start_push

**Data:**

**Example:**

`\{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp:": 1654070968655,	"method": "live_start_push",	"data": \{		"result": 0	\}\}`

停止直播[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/30#%E5%81%9C%E6%AD%A2%E7%9B%B4%E6%92%AD "停止直播的直接链接")
-----------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** live_stop_push

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| video_id | 直播视频流的ID编号 | text | {} | 格式为 #{uav_sn}/#{camera_id}/#{video_index};无人机SN号/负载及挂载位置枚举值/负载lens编号 比如机巢推流ID"1748FEV3HMA923171787/nest-camera-out/normal"， 无人机推流ID "1748FEV3HMA923171787/drone-camera-0/normal" |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp:": 1654070968655,	"method": "live_stop_push",	"data": {		"video_id": "1748FEV3HMA923171787/drone-camera-0/normal"	}}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** live_stop_push

**Data:** null

**Example:**

`\{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp:": 1654070968655,	"method": "live_stop_push",	"data": \{		"result": 0	\}\}`
