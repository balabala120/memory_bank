# example of the osd message of nest
``` json
{
    "bid": "1f3dff9b-a5e4-44f0-b8b0-eec7056ea1c9",
    "data": {
        "air_conditioner": {
            "air_conditioner_state": 0
        },
        "airspeed_calibrate_status": 0,
        "alarm_state": 0,
        "alternate_land_point": {
            "latitude": 23.035883,
            "longitude": 114.2304301,
            "safe_land_height": 6.6,
            "is_configured": 1
        },
        "backup_battery": {
            "remain_cap": 100,
            "temperature": 29.0,
            "voltage": 2462,
            "switch": 1
        },
        "cover_state": 0,
        "df_dock_recycler_status": 0,
        "df_dock_reset_status": 0,
        "df_prepare_takeoff_status": 0,
        "df_replace_battery_status": 0,
        "dock_ip_addr": "192.168.10.96",
        "drc_state": 0,
        "drone_charge_state": {
            "capacity_percent": 100,
            "state": 0
        },
        "drone_in_dock": 1,
        "emergency_stop_state": 0,
        "environment_humidity": 90.0,
        "environment_temperature": 18.8,
        "firmware_version": "1.6.0.154",
        "flighttask_step_code": 5,
        "height": 13.4637,
        "humidity": 63,
        "latitude": 23.03579175186,
        "live_capacity": {
            "available_video_number": 1,
            "coexist_video_number_max": 1,
            "device_list": [
                {
                    "available_video_number": 1,
                    "camera_list": [
                        {
                            "availabe_camera_positions": [
                                0
                            ],
                            "available_video_number": 1,
                            "camera_index": "10165-0-0",
                            "camera_position": 1,
                            "coexist_video_number_max": 1,
                            "video_list": [
                                {
                                    "switchable_video_types": [
                                        "normal"
                                    ],
                                    "video_index": "normal-0",
                                    "video_type": "normal"
                                }
                            ]
                        }
                    ],
                    "coexist_video_number_max": 1,
                    "sn": "NM1923371002"
                }
            ]
        },
        "live_status": [
            {
                "error_status": 0,
                "status": 1,
                "video_id": "NM1923371002/10165-0-0/normal-0",
                "video_quality": 0,
                "video_type": "normal"
            }
        ],
        "longitude": 114.2302203332,
        "maintain_status": {
            "maintain_status_array": [
                {
                    "last_maintain_flight_sorties": 0,
                    "last_maintain_time": 1762849590437,
                    "last_maintain_type": 17,
                    "state": 0
                }
            ]
        },
        "media_file_detail": {
            "remain_upload": 0
        },
        "mode_code": 0,
        "nest_camera_connect_state": 1,
        "nest_rtk_fix_status": 0,
        "nest_rtk_work_mode": 1,
        "network_state": {
            "quality": 1,
            "rate": 28.382813,
            "type": 2
        },
        "position_state": {
            "is_fixed": 2,
            "is_calibration": 1
        },
        "pressure": 0.0,
        "putter_state": 0,
        "rainfall": 0,
        "rid_config": {
            "region": 0
        },
        "rth_altitude": 114,
        "scram_status": 0,
        "state": 121,
        "storage": {
            "current_used": 1,
            "storage_type": 1,
            "total": 27498348,
            "used": 18712696
        },
        "sub_device": {
            "device_online_status": 0,
            "device_paired": 0,
            "firmware_version": "1.9.4.22"
        },
        "supplement_light_state": 0,
        "takeoff_altitude": 110,
        "temperature": 20.8,
        "wind_speed": 0.52,
        "wireless_link": {
            "fourth_link_error_msg": "Login Success",
            "link_workmode": 1,
            "sdr_link_state": 0,
            "sdr_quality": 0,
            "cellular_uav_server_state": 1,
            "4g_sdr_fusion_state": 1
        }
    },
    "gateway": "NM1923371002",
    "tid": "4b00a5f1-353d-401c-9ab0-3a0f12aabe6e",
    "timestamp": 1765973131852
}
```

# example of the osd message of drone
```
{
    "bid": "214fef8d-6668-4b73-8d78-d0a33c859c8c",
    "data": {
        "activation_time": 1766389332771,
        "ai_enable_func": 0,
        "attitude_head": -179.21976,
        "attitude_pitch": 3.9158082008361816,
        "attitude_roll": -0.3810422420501709,
        "battery": {
            "capacity_percent": 99
        },
        "cameras": [
            {
                "camera_mode": 101,
                "ir_zoom_factor": 1,
                "payload_index": "10865-0-0",
                "photo_state": 0,
                "photo_storage_settings": [],
                "record_time": 0,
                "recording_state": 0,
                "remain_photo_num": 1000,
                "remain_record_duration": 1000,
                "screen_split_enable": 0,
                "video_storage_settings": [],
                "zoom_factor": 1,
                "ir_metering_mode": 0
            }
        ],
        "compatible_status": 0,
        "country": "CN",
        "distance_limit_status": {
            "distance_limit": 100000,
            "state": 0,
            "is_near_distance_limit": 0
        },
        "elevation": 0,
        "exit_wayline_when_rc_lost": 0,
        "height": 27.656,
        "height_limit": 120,
        "home_distance": 0,
        "horizontal_speed": 0,
        "latitude": 23.035841,
        "longitude": 114.230255,
        "manual_ctrl_gimbal": 0,
        "mode_code": 0,
        "night_lights_state": 0,
        "obstacle_avoidance": {
            "downside": 1,
            "horizon": 1,
            "upside": 1
        },
        "position_state": {
            "calibration": 0,
            "coordinate_sys": 0,
            "fix_sta": 0,
            "gps_number": 39,
            "quality": 0,
            "rtk_number": 0,
            "rtk_hgt": 0,
            "rtk_inpos": 0,
            "rtk_lat": 0,
            "rtk_lon": 0,
            "rtk_used": 0
        },
        "rc_lost_action": 2,
        "rid_state": 1,
        "rth_altitude": 120,
        "storage": {
            "current_used": 1,
            "storage_type": 1,
            "total": 67988480,
            "used": 3674112
        },
        "total_flight_time": 21976,
        "vertical_speed": 0,
        "wind_speed": 0.61,
        "airspeed_calibrate_status": 0,
        "alarm_status": 0,
        "fly_state": 0,
        "gear_level": 2,
        "gimbal_angle_follow_toggle": 0,
        "hae": 25.59,
        "infrared_camera_temp_data": {
            "average_temp": 196,
            "camera_id": 1,
            "center_temp": 193,
            "cold_temp": 186,
            "cold_x": 0,
            "cold_y": 0,
            "hot_temp": 204,
            "hot_x": 0,
            "hot_y": 0,
            "touch_temp": 193,
            "zoom_value": 100
        },
        "infrared_palette_mode": 0,
        "laser_distance_data": {
            "laser_distance": 320,
            "laser_distance_is_valid": 0
        },
        "live_fps_stats": {
            "recv_frame_stats": [
                {
                    "fps_video_type": "ir",
                    "lag_count": 0,
                    "fps_count": 31
                },
                {
                    "fps_video_type": "NightVision",
                    "lag_count": 0,
                    "fps_count": 16
                }
            ],
            "send_frame_stats": [
                {
                    "fps_video_type": "NightVision",
                    "lag_count": 0,
                    "fps_count": 16
                }
            ]
        },
        "main_mode": 2,
        "ned_altitude": 0,
        "ned_latitude": 0,
        "ned_longitude": 0,
        "ntrip_status": "error",
        "out_of_control_action": 2,
        "pos_type": "null",
        "remain_distance": 0,
        "remote_id_status": 1,
        "sn": "1748FEV3HMB923551024",
        "total_armed_time": 0,
        "vel_ned_x": 0,
        "vel_ned_y": 0,
        "vel_ned_z": 0,
        "wireless_link": {
            "4g_uav_quality": 3
        },
        "is_near_area_limit": 0,
        "is_near_height_limit": 0,
        "10865-0-0": {
            "gimbal_pitch": -0.07,
            "gimbal_roll": 0,
            "gimbal_yaw": -179.23,
            "payload_index": "10865-0-0",
            "zoom_factor": 1,
            "measure_target_error_state": 1,
            "thermal_current_palette_style": 0,
            "thermal_supported_palette_styles": [
                30,
                31,
                34,
                32,
                33,
                35,
                36,
                37,
                38,
                39
            ]
        }
    },
    "gateway": "NM1923371002",
    "tid": "d7b0368e-ae34-40fb-8f4b-29bccc2531a8",
    "timestamp": 1766389332766
}
```