mqtt:
  broker: emqx-dev-feature.autelrobotics.cn
  port: 31883
  username: "10072"
  password: "7EGT7SPDZ1"