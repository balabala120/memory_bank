Title: 航线管理 | Cloud API

URL Source: https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/50#%E4%B8%80%E9%94%AE%E8%BF%94%E8%88%AA

Markdown Content:
航线管理
----

Event[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/50#event "Event的直接链接")
------------------------------------------------------------------------------------------

上报航线任务进度[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/50#%E4%B8%8A%E6%8A%A5%E8%88%AA%E7%BA%BF%E4%BB%BB%E5%8A%A1%E8%BF%9B%E5%BA%A6 "上报航线任务进度的直接链接")
-------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/events

**Direction:** up

**Method:** flighttask_progress

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| output | 内容 | struct |  |  |
| »ext | 扩展内容 | struct |  |  |
| »»current_waypoint_index | 当前执行到的航点数 | int |  |  |
| »»media_count | 本次航线任务执行产生的媒体文件数量 | int |  |  |
| »»flight_id | 任务 ID | text |  |  |
| »»break_point | 航线断点信息 | struct | 可选字段，用于告知云端本次航线任务断点信息 |  |
| »»»index | 断点序号 | int |  |  |
| »»»state | 断点状态 | enum_int | {"0":"在航段上","1":"在航点上"} |  |
| »»»progress | 当前航段进度 | int | {"max":"100","min":"0"} |  |
| »»»wayline_id | 航线 ID | int |  |  |
| »»»latitude | 断点纬度 | float | {"max":"90","min":"-90","unit":"度 / °"} |  |
| »»»longitude | 断点经度 | float | {"max":"180","min":"-180","unit":"度 / °"} |  |
| »»»height | 断点相对地球椭球面高度 | float | {"unit":"米 / m"} |  |
| »status | 任务状态 | enum_string | {”pending“:"开始执行"，"canceled":"取消或终止","failed":"失败","in_progress":"执行中","ok":"执行成功","partially_done":"部分完成","paused":"暂停","rejected":"拒绝","sent":"已下发","timeout":"超时"} |  |
| »progress | 进度 | struct |  |  |
| »»current_step | 执行步骤 | enum_int | {"0":"初始状态","1":"启动前检查，无人机是否在执行航线中","2":"启动前检查，机场是否退出工作模式","3":"启动前检查，航线执行中","4":"启动前检查，返航中","5":"航线执行进入准备状态，开始等待任务下发","6":"机场进入工作状态","7":"进入开机检查准备工作和开盖准备工作","8":"等待飞行系统准备就绪，推送连接建立","9":"等待 RTK 源监听有值上报","10":"检查 RTK 是否就绪“,"14":"下载 任务文件","15":"任务文件上传中";,"17":"无人机起飞参数设置，备降点设置，起飞高度设置"18":"无人机 flyto 起飞参数设置","19":"Home 点设置","20":"触发执行航线","21":"航线执行中","22":"返航","23":"无人机降落机场","24":"降落以后的关盖","29":"获取媒体文件数量","46":"上传图片",,"47":"任务完成","0xFFFD":"结束后等待服务回包","0xFFFE":"无具体状态","0xFFFFF":"UNKNOWN"} |  |
| »»percent | 进度值 | int | {"max":"100","min":"0",} |  |
| result | 结果 | int | 返回0成功，非零失败（失败原因见错误码） |  |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"output": {			"ext": {				"current_waypoint_index": 3,				"flight_id": "flight_id",				"media_count": 6,			},			"progress": {				"current_step": 19,				"percent": 100			},			"status": "ok"		},		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1654070968655,	"method": "flighttask_progress"}`

下发任务[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/50#%E4%B8%8B%E5%8F%91%E4%BB%BB%E5%8A%A1 "下发任务的直接链接")
-----------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** flighttask_prepare

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| flight_id | 计划 ID | text |  |  |
| execute_time | 开始执行时间 | int | {"length":13} | 任务开始执行时间毫秒时间戳。可选字段。当 `task_type` 为 0 或 1 时必填，为 2 时非必填。 |
| task_type | 任务类型 | enum_int | {"0":"立即任务","1":"定时任务",} | 立即任务和定时任务均由 `execute_time` 指定执行时间。条件任务支持 `ready_conditions` 字段指定任务就绪条件。任务可在指定时间段内满足一定条件后即可执行。立即任务媒体上传优先级最高，定时任务和条件任务媒体上传优先级相同。 |
| wayline_type | 航线类型 | enum_int | {"0":"普通航点航线"} |  |
| file | 航线文件对象 | struct |  |  |
| »url | 文件 URL | text |  |  |
| »fingerprint | 文件 MD5 签名 | text |  |  |
| rth_altitude | 返航高度 | int | {"max":1500,"min":20,"unit_name":"米 / m"} | 相对地面高度 |
| out_of_control_action | 遥控器失控动作 | enum_int | {"0":"返航","1":"悬停","2":"降落"} | 失控动作，当前固定传的值是 0，即返航。注意该枚举值定义跟飞控跟机场定义的不一致，机场端会进行转换。 |
| exit_wayline_when_rc_lost | 航线失控动作 | enum_int | {"0":"继续执行航线任务","1":"退出航线任务，执行遥控器失控动作"} | 保持跟 KMZ 文件一致 |
| wayline_precision_type | 航线精度类型 | enum_int | {0:"GPS 任务"， 1： "高精度RTK任务"} |  |
| barrier_switch_state | 避障开关 | enum_int | {0：关闭避障， 1， 打开避障} | 注意，1.4版本的机巢固件是{0：打开避障， 1， 关闭避障} 1.4以上的机巢固件版本都是 {0：关闭避障， 1， 打开避障} |
| takeoff_altitude | 起飞高度 | int |  | 相对地面高度 |
| first_waypoint_speed | 去首航点的速度 | int |  |  |
| return_speed | 去首航点的速度 | int |  |  |
| media_upload_method | 媒体文件上传方式 | enum_int | {0:落地上传， 1:变飞边传} |  |
| alternate_land_point | 备降点 | struct |  |  |
| longitude | 经度 | double |  |  |
| latitude | 纬度 | double |  |  |
| safe_land_height | 安全高度 | float |  |  |
| is_configured | 是否设置备降点 | enum_int | {0:未设置，1：已设置} |  |
| break_point | 航线断点信息 | struct | 可选字段，用于断点续飞，若下发该字段，航线任务会从字段指定的断点位置开始执行。 |  |
| »index | 断点序号 | 断点序号 |  |  |
| »state | 断点状态 | enum_int | {"0":"在航段上","1":"在航点上"} |  |
| »wayline_id | 航线 ID | int | 下发断点执行需要带上进度上报中上报的这个ID |  |

**Example:**

`{  "timestamp" : "1715693761421",  "data" : {    "flight_id" : "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",     "execute_time" : "1715693761357",    "task_type" : 0,    "wayline_type" : 0,    "file" : {      "url" : "http://139.9.78.181:9000/autel-store/20240514/7dc350b0-33dc-4795-aac6-b0b9c88384b8-181153706728624128.aut",      "fingerprint" : "ebf5f3c1ee5228edd96943ade9dda33d"    },    "rth_altitude" : 100,    "exit_wayline_when_rc_lost" : 0,    "alternate_land_point" : {      "longitude" : 114.2304316,      "latitude" : 23.0358027,      "safe_land_height" : 10,      "is_configured" : 1    },    "wayline_precision_type" : 1,    "takeoff_altitude" : 100,    "first_waypoint_speed" : 10,    "return_speed" : 10,    "media_upload_method" : 0  },  "method" : "flighttask_prepare",  "tid" : "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",  "bid" : "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",  "gateway" : "NM1923371013"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** flighttask_prepare

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{    "bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "data": {        "result": 0    },    "gateway": "NM1923371013",    "tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "timestamp": 1715693761468,    "method": "flighttask_prepare"}`

执行任务[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/50#%E6%89%A7%E8%A1%8C%E4%BB%BB%E5%8A%A1 "执行任务的直接链接")
-----------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** flighttask_execute

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| flight_id | 计划 ID | text |  |  |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"flight_id": "xxxxxxx"	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1234567890123,	"method": "flighttask_execute"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** flighttask_execute

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1234567890123,	"method": "flighttask_execute"}`

一键返航[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/50#%E4%B8%80%E9%94%AE%E8%BF%94%E8%88%AA "一键返航的直接链接")
-----------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** return_home

**Data:** null

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** return_home

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |
| output | 输出 | struct |  |  |
| »status | 任务状态 | enum_string | {"canceled":"取消或终止","failed":"失败","in_progress":"执行中","ok":"执行成功","paused":"暂停","rejected":"拒绝","sent":"已下发","timeout":"超时"} |  |

航线暂停[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/50#%E8%88%AA%E7%BA%BF%E6%9A%82%E5%81%9C "航线暂停的直接链接")
-----------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** flighttask_pause

**Data:** null

**Example:**

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** flighttask_pause

**Data:**

| **Column** | **Name** | **Type** | **constraint** | **Description** |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

航线恢复[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/50#%E8%88%AA%E7%BA%BF%E6%81%A2%E5%A4%8D "航线恢复的直接链接")
-----------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** flighttask_recovery

**Data:** null

**Example:**

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** flighttask_recovery

**Data:**

| **Column** | **Name** | **Type** | **constraint** | **Description** |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

取消任务[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/50#%E5%8F%96%E6%B6%88%E4%BB%BB%E5%8A%A1 "取消任务的直接链接")
-----------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** flighttask_undo

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| flight_ids | 计划 ID | array | {"size": -, "item_type": text} |  |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"flight_ids": [			"aaaaaaa",			"bbbbbbb"		]	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1234567890123,	"method": "flighttask_undo"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** flighttask_undo

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"result": 0	},	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 1234567890123,	"method": "flighttask_undo"}`

取消返航[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/50#%E5%8F%96%E6%B6%88%E8%BF%94%E8%88%AA "取消返航的直接链接")
-----------------------------------------------------------------------------------------------------------------------

返航后，无人机会退出航线模式，此时取消返航，无人机会悬停

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** return_home_cancel

**Data:** null

**Example:**

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** return_home_cancel

**Data:**

| **Column** | **Name** | **Type** | **constraint** | **Description** |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

兴趣点任务执行结果事件通知[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/50#%E5%85%B4%E8%B6%A3%E7%82%B9%E4%BB%BB%E5%8A%A1%E6%89%A7%E8%A1%8C%E7%BB%93%E6%9E%9C%E4%BA%8B%E4%BB%B6%E9%80%9A%E7%9F%A5 "兴趣点任务执行结果事件通知的直接链接")
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/events

**Direction:** up

**Method:** flight_task_poi_progress

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| fly_to_id | 飞向目标点 ID | text |  |  |
| status | 状态 | enum_string | {"wayline_cancel":"取消飞向目标点","wayline_failed":"执行失败","wayline_ok":"执行成功，已飞向目标点","wayline_progress":"执行中"} |  |
| result | 返回码 | int |  | 非 0 代表错误 |
| remaining_distance | 剩余任务距离 | float | {"step":0.1,"unit_name":"米 / m"} |  |
| remaining_time | 剩余任务时间 | float | {"step":0.1,"unit_name":"秒 / s"} |  |
| planned_path_points | 规划的轨迹点列表 | array | {"size": -, "item_type": struct} |  |
| »latitude | 轨迹点纬度(角度值) | double | {"max":90,"min":-90} | 轨迹点纬度，角度值，南纬是负，北纬是正，精度到小数点后6位 |
| »longitude | 轨迹点经度(角度值) | double | {"max":180,"min":-180} | 轨迹点经度，角度值，东经是正，西经是负，精度到小数点后6位 |
| »height | 轨迹点高度 | float | {"step":0.1,"unit_name":"米 / m"} | 轨迹点高度,椭球高 |

**Example:**

`{	"bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"data": {		"fly_to_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",		"planned_path_points": [			{				"height": 123.234,				"latitude": 13.23,				"longitude": 123.234			}		],		"remaining_distance": 0,		"remaining_time": 0,		"result": 0,		"status": "wayline_progress",		"way_point_index": 0	},	"need_reply": 1,	"tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",	"timestamp": 16540709686556,	"method": "flight_task_poi_progress"}`

兴趣点任务[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/50#%E5%85%B4%E8%B6%A3%E7%82%B9%E4%BB%BB%E5%8A%A1 "兴趣点任务的直接链接")
----------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** flight_task_poi

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| id | 任务id | int |  |  |
| type | 任务类型 | enum_int | {1: 无人机朝向兴趣点，不动,3: 飞向兴趣点位置后，朝向兴趣点} |  |
| lat | 纬度 | long | 兴趣点任务纬度(WGS84),纬度 * 1E7,采⽤⼩端编码,即低有效字节 |  |
| lon | 经度 | long | 兴趣点任务点经度(WGS84),经度 * 1E7 ,采⽤⼩端编码,即低有效字节 |  |
| alt | 高度 | long | 兴趣点任务点⾼度单位mm, 采⽤⼩端编码,即低有效字节在前 |  |

**Example:**

`{  "data" : {    "id" : 1001,     "type" : 1,     "lat" : 23.0000000,     "lon" : 113.0000000,    "alt" : 10  },  "method" : "flight_task_poi",  "tid" : "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",  "bid" : "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** flight_task_poi

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{    "bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "data": {        "result": 0    },    "tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "timestamp": 1715693761468,    "method": "flight_task_poi"}`

取消兴趣点任务[​](https://doc-test.autelrobotics.cn/cloud_api/cn/60/20/00/20/50#%E5%8F%96%E6%B6%88%E5%85%B4%E8%B6%A3%E7%82%B9%E4%BB%BB%E5%8A%A1 "取消兴趣点任务的直接链接")
--------------------------------------------------------------------------------------------------------------------------------------------------------

**Topic:** thing/product/_{gateway\_sn}_/services

**Direction:** down

**Method:** cancel_flight_task_poi

**Data:**

**Example:**

`{  "data" : {  },  "method" : "cancel_flight_task_poi",  "tid" : "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",  "bid" : "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx"}`

**Topic:** thing/product/_{gateway\_sn}_/services_reply

**Direction:** up

**Method:** cancel_flight_task_poi

**Data:**

| Column | Name | Type | constraint | Description |
| --- | --- | --- | --- | --- |
| result | 返回码 | int |  | 非 0 代表错误 |

**Example:**

`{    "bid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "data": {        "result": 0    },    "tid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx",    "timestamp": 1715693761468,    "method": "cancel_flight_task_poi"}`
