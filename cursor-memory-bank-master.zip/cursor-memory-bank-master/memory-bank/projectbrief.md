# Memory Bank: 项目简介

## 项目概述

**项目名称:** 无人机机巢MQTT Mock系统

**项目类型:** Python MQTT模拟服务

**创建日期:** 2026-01-16

## 项目目标

开发一个完整的无人机机巢MQTT mock系统，用于：
- 模拟机巢设备的所有MQTT通信行为
- 接收并响应所有下行指令
- 定时上报OSD（On-Screen Display）状态消息
- 支持测试和开发环境使用

## 核心功能

1. **MQTT通信**
   - 连接MQTT Broker
   - 订阅下行指令主题
   - 发布上行回复和事件

2. **指令处理**
   - 解析下行指令
   - 生成标准回复
   - 维护指令状态

3. **OSD上报**
   - 生成机巢OSD数据
   - 生成无人机OSD数据
   - 定时上报机制

## 技术文档位置

项目文档位于 `docs/` 目录：
- `mqtt-config.md` - MQTT配置信息
- `fight-task-mqtt-guide.md` - 航线管理MQTT指南
- `fly-control-mqtt-guide.md` - 指令飞行MQTT指南
- `osd-mqtt-example.md` - OSD消息示例

## 项目状态

**当前阶段:** 初始化（VAN模式）
**下一步:** 进入PLAN模式进行详细规划

