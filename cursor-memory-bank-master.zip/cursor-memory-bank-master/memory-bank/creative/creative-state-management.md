# 创意阶段：状态管理设计

> **创建日期:** 2026-01-16
> **任务ID:** TASK-001
> **状态:** 完成

---

📌 创意阶段开始：状态管理设计
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 1️⃣ 问题

**描述:** 如何管理复杂的机巢和无人机设备状态，确保指令处理与OSD上报的状态一致性？

**需求:**
- 维护机巢状态（cover_state, drone_in_dock, flighttask_step_code等）
- 维护无人机状态（position, battery, mode_code等）
- 指令处理器可以读取和更新状态
- OSD生成器可以读取状态
- 状态变化应该是线程安全的

**约束:**
- 单进程运行，但需考虑回调的并发性
- Mock场景不需要持久化
- 状态结构应与OSD数据结构对应
- 简单实现优先

---

## 2️⃣ 选项

### 选项 A：简单字典
使用Python字典存储状态，直接读写。

### 选项 B：数据类封装
使用dataclass定义状态结构，封装在StateManager类中。

### 选项 C：状态机模式
使用有限状态机管理设备状态转换。

### 选项 D：响应式状态
使用观察者模式，状态变化时通知订阅者。

---

## 3️⃣ 分析

| 标准 | 选项 A | 选项 B | 选项 C | 选项 D |
|------|--------|--------|--------|--------|
| 实现简单度 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ |
| 类型安全 | ⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| 可维护性 | ⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| 扩展性 | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| Mock场景适用 | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ |

**关键见解:**
- 字典简单但容易出错，缺乏类型检查
- dataclass提供清晰的结构和类型提示
- 状态机对Mock场景过于复杂
- 响应式模式增加不必要的复杂性

---

## 4️⃣ 决策

**选定:** 选项 B：数据类封装

**理由:**
1. **类型安全:** dataclass提供类型提示，IDE支持好
2. **结构清晰:** 状态字段一目了然
3. **默认值支持:** 方便初始化Mock状态
4. **易于扩展:** 添加新字段简单直接
5. **测试友好:** 可以轻松创建测试状态

---

## 5️⃣ 实施说明

### 状态管理架构

```
┌─────────────────────────────────────────────────────────────────┐
│                        StateManager                              │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │  - dock_state: DockState                                    ││
│  │  - drone_state: DroneState                                  ││
│  │  - _lock: threading.RLock()  # 线程安全                     ││
│  └─────────────────────────────────────────────────────────────┘│
│                                                                 │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │  读取方法:                                                   ││
│  │  - get_dock_state() -> DockState (返回副本)                 ││
│  │  - get_drone_state() -> DroneState (返回副本)               ││
│  └─────────────────────────────────────────────────────────────┘│
│                                                                 │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │  更新方法:                                                   ││
│  │  - update_dock_state(**kwargs)                              ││
│  │  - update_drone_state(**kwargs)                             ││
│  │  - set_flight_task_step(step_code: int)                     ││
│  │  - set_drone_position(lat, lon, height)                     ││
│  │  - set_drone_flying(is_flying: bool)                        ││
│  └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
           │                                    │
           │ 读取                               │ 更新
           ▼                                    ▼
┌──────────────────────┐            ┌──────────────────────┐
│    OSDGenerator      │            │      Handlers        │
│  - 生成OSD时读取状态  │            │  - 处理指令时更新状态 │
└──────────────────────┘            └──────────────────────┘
```

### 状态数据结构

```python
from dataclasses import dataclass, field
from typing import Optional, List, Dict
import copy
import threading

@dataclass
class DockState:
    """机巢状态"""
    # 基础状态
    cover_state: int = 0           # 舱盖: 0=关闭, 1=开启
    drone_in_dock: int = 1         # 无人机在巢: 0=否, 1=是
    putter_state: int = 0          # 推杆状态
    emergency_stop_state: int = 0  # 急停状态
    scram_status: int = 0          # 急停按钮状态
    
    # 任务状态
    flighttask_step_code: int = 5  # 航线任务步骤码
    mode_code: int = 0             # 机巢模式
    drc_state: int = 0             # DRC状态: 0=未进入, 1=已进入
    state: int = 121               # 机巢整体状态
    
    # 无人机充电状态
    drone_charge_capacity: int = 100
    drone_charge_state: int = 0    # 0=未充电, 1=充电中
    
    # 环境数据
    environment_temperature: float = 25.0
    environment_humidity: float = 60.0
    temperature: float = 25.0
    humidity: int = 60
    wind_speed: float = 2.0
    rainfall: int = 0
    pressure: float = 0.0
    
    # 位置
    latitude: float = 23.035792
    longitude: float = 114.230220
    height: float = 13.46
    
    # 返航高度和起飞高度
    rth_altitude: int = 114
    takeoff_altitude: int = 110
    
    # 备降点
    alternate_land_point: Dict = field(default_factory=lambda: {
        "latitude": 23.035883,
        "longitude": 114.2304301,
        "safe_land_height": 6.6,
        "is_configured": 1
    })
    
    # 固件版本
    firmware_version: str = "1.6.0.154"
    
    # 网络信息
    dock_ip_addr: str = "192.168.10.96"


@dataclass
class DroneState:
    """无人机状态"""
    # SN
    sn: str = "1748FEV3HMB923551024"
    
    # 位置
    latitude: float = 23.035841
    longitude: float = 114.230255
    height: float = 27.656
    elevation: float = 0.0
    
    # 姿态
    attitude_head: float = 0.0
    attitude_pitch: float = 0.0
    attitude_roll: float = 0.0
    
    # 速度
    horizontal_speed: float = 0.0
    vertical_speed: float = 0.0
    
    # 电池
    battery_percent: int = 100
    
    # 飞行状态
    mode_code: int = 0     # 0=待机, 1=起飞中, 2=飞行中, etc.
    fly_state: int = 0     # 飞行子状态
    main_mode: int = 2
    
    # 云台
    gimbal_pitch: float = 0.0
    gimbal_roll: float = 0.0
    gimbal_yaw: float = 0.0
    
    # 相机
    camera_mode: int = 101
    recording_state: int = 0
    photo_state: int = 0
    zoom_factor: float = 1.0
    
    # 返航相关
    home_distance: float = 0.0
    rth_altitude: int = 120
    height_limit: int = 120
    rc_lost_action: int = 2
    
    # 避障
    obstacle_avoidance_downside: int = 1
    obstacle_avoidance_horizon: int = 1
    obstacle_avoidance_upside: int = 1
    
    # 固件版本（从sub_device）
    firmware_version: str = "1.9.4.22"
    
    # 飞行时间
    total_flight_time: int = 21976


class StateManager:
    """状态管理器 - 单例模式"""
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls, gateway_sn: str = "NM1923371002"):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self, gateway_sn: str = "NM1923371002"):
        if self._initialized:
            return
        
        self.gateway_sn = gateway_sn
        self._dock_state = DockState()
        self._drone_state = DroneState()
        self._state_lock = threading.RLock()
        self._initialized = True
    
    # ===== 读取方法 =====
    
    def get_dock_state(self) -> DockState:
        """获取机巢状态副本（线程安全）"""
        with self._state_lock:
            return copy.deepcopy(self._dock_state)
    
    def get_drone_state(self) -> DroneState:
        """获取无人机状态副本（线程安全）"""
        with self._state_lock:
            return copy.deepcopy(self._drone_state)
    
    # ===== 通用更新方法 =====
    
    def update_dock_state(self, **kwargs):
        """更新机巢状态"""
        with self._state_lock:
            for key, value in kwargs.items():
                if hasattr(self._dock_state, key):
                    setattr(self._dock_state, key, value)
    
    def update_drone_state(self, **kwargs):
        """更新无人机状态"""
        with self._state_lock:
            for key, value in kwargs.items():
                if hasattr(self._drone_state, key):
                    setattr(self._drone_state, key, value)
    
    # ===== 便捷更新方法 =====
    
    def set_flight_task_step(self, step_code: int):
        """设置航线任务步骤"""
        self.update_dock_state(flighttask_step_code=step_code)
    
    def set_drone_in_dock(self, in_dock: bool):
        """设置无人机在巢状态"""
        self.update_dock_state(drone_in_dock=1 if in_dock else 0)
    
    def set_cover_state(self, is_open: bool):
        """设置舱盖状态"""
        self.update_dock_state(cover_state=1 if is_open else 0)
    
    def set_drc_mode(self, enabled: bool):
        """设置DRC模式"""
        self.update_dock_state(drc_state=1 if enabled else 0)
    
    def set_drone_position(self, latitude: float, longitude: float, 
                           height: float):
        """设置无人机位置"""
        self.update_drone_state(
            latitude=latitude,
            longitude=longitude,
            height=height
        )
    
    def set_drone_flying(self, is_flying: bool):
        """设置无人机飞行状态"""
        self.update_drone_state(
            mode_code=2 if is_flying else 0,
            fly_state=1 if is_flying else 0
        )
    
    def set_drone_battery(self, percent: int):
        """设置无人机电量"""
        self.update_drone_state(battery_percent=percent)
    
    def set_gimbal_angle(self, pitch: float = None, roll: float = None, 
                         yaw: float = None):
        """设置云台角度"""
        updates = {}
        if pitch is not None:
            updates['gimbal_pitch'] = pitch
        if roll is not None:
            updates['gimbal_roll'] = roll
        if yaw is not None:
            updates['gimbal_yaw'] = yaw
        if updates:
            self.update_drone_state(**updates)
    
    def set_camera_recording(self, is_recording: bool):
        """设置录像状态"""
        self.update_drone_state(recording_state=1 if is_recording else 0)
    
    # ===== 状态重置 =====
    
    def reset_to_idle(self):
        """重置到空闲状态"""
        self._dock_state = DockState()
        self._drone_state = DroneState()
```

### 处理器中的状态使用示例

```python
@handler("flighttask_prepare")
class FlighttaskPrepareHandler(BaseHandler):
    def handle(self, message: dict) -> dict:
        # 更新任务步骤
        self.state_manager.set_flight_task_step(5)  # 准备状态
        
        # 记录flight_id（如果需要）
        flight_id = message["data"].get("flight_id")
        
        return self.success_response(message)


@handler("drc_mode_enter")
class DrcModeEnterHandler(BaseHandler):
    def handle(self, message: dict) -> dict:
        # 进入DRC模式
        self.state_manager.set_drc_mode(True)
        
        return self.success_response(message)


@handler("gimbal_reset")
class GimbalResetHandler(BaseHandler):
    def handle(self, message: dict) -> dict:
        reset_mode = message["data"].get("reset_mode", 0)
        
        # 根据重置模式设置云台角度
        if reset_mode == 0:  # 回中
            self.state_manager.set_gimbal_angle(pitch=0, yaw=0)
        elif reset_mode == 1:  # 向下
            self.state_manager.set_gimbal_angle(pitch=-90)
        
        return self.success_response(message)
```

### 线程安全考虑

```
┌─────────────────────────────────────────────────────────────────┐
│                     线程安全策略                                   │
├─────────────────────────────────────────────────────────────────┤
│  1. 所有状态访问通过StateManager封装                               │
│  2. 使用threading.RLock保护状态读写                               │
│  3. get_*_state返回深拷贝，避免外部修改                            │
│  4. 单例模式确保全局唯一状态实例                                    │
│  5. RLock支持同一线程多次获取（可重入）                            │
└─────────────────────────────────────────────────────────────────┘
```

---

## ✅ 验证

**需求满足情况:**
- [x] 维护机巢状态
- [x] 维护无人机状态
- [x] 指令处理器可读写状态
- [x] OSD生成器可读取状态
- [x] 线程安全

**技术可行性:** 高 - 使用Python标准库实现

**风险评估:** 低 - dataclass设计简单可靠

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 创意阶段结束

