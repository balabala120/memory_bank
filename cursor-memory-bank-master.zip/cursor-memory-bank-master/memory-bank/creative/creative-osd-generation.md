# 创意阶段：OSD数据生成策略

> **创建日期:** 2026-01-16
> **任务ID:** TASK-001
> **状态:** 完成

---

📌 创意阶段开始：OSD数据生成策略
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 1️⃣ 问题

**描述:** 如何生成合理的模拟OSD数据，使其既符合真实设备的数据格式，又能反映模拟的设备状态变化？

**需求:**
- 生成机巢OSD数据（dock_osd）
- 生成无人机OSD数据（device_osd）
- 数据结构符合Cloud API规范
- 支持1-30Hz的上报频率
- 数据应有合理的变化模式

**约束:**
- 遵循现有文档中的OSD示例格式
- 关键字段必须包含（bid, tid, timestamp, data, gateway）
- 某些数据应随状态变化（如电量、位置）
- 性能要求：生成延迟<10ms

---

## 2️⃣ 选项

### 选项 A：静态模板
从示例数据创建静态模板，仅更新timestamp和bid/tid。

### 选项 B：随机变化
在基础模板上，对数值字段添加随机波动。

### 选项 C：状态驱动
根据StateManager中的设备状态生成OSD，状态变化反映在OSD中。

### 选项 D：模拟轨迹
预定义飞行轨迹和状态变化序列，按时间线播放。

---

## 3️⃣ 分析

| 标准 | 选项 A | 选项 B | 选项 C | 选项 D |
|------|--------|--------|--------|--------|
| 实现简单度 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ |
| 真实感 | ⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| 状态一致性 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| 可扩展性 | ⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| 测试友好 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |

**关键见解:**
- 静态模板最简单但缺乏真实感
- 随机变化可能导致状态不一致（如电量突然增加）
- 状态驱动确保OSD与系统状态同步
- 模拟轨迹过于复杂，不适合Mock场景

---

## 4️⃣ 决策

**选定:** 选项 C：状态驱动（带轻微随机波动）

**理由:**
1. **状态一致性:** OSD数据与处理器更新的状态保持同步
2. **可预测性:** 测试时可以验证状态变化反映在OSD中
3. **适度真实:** 传感器数据（温度、风速）添加小幅波动更真实
4. **简单实现:** 比完整模拟轨迹简单得多
5. **可扩展:** 便于未来添加更复杂的模拟逻辑

---

## 5️⃣ 实施说明

### OSD生成架构

```
┌─────────────────────────────────────────────────────────────────┐
│                    StateManager (状态源)                          │
│  ┌─────────────────────────┐  ┌─────────────────────────┐       │
│  │      DockState          │  │      DroneState         │       │
│  │  - cover_state          │  │  - latitude             │       │
│  │  - drone_in_dock        │  │  - longitude            │       │
│  │  - flighttask_step_code │  │  - height               │       │
│  │  - drone_charge_state   │  │  - battery              │       │
│  │  - environment_*        │  │  - attitude_*           │       │
│  └─────────────────────────┘  │  - mode_code            │       │
│                               └─────────────────────────┘       │
└─────────────────────────────────────────────────────────────────┘
                                   │
                                   │ 读取状态
                                   ▼
┌─────────────────────────────────────────────────────────────────┐
│                     OSDGenerator                                  │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │  def generate_dock_osd(self) -> dict:                       ││
│  │      state = self.state_manager.get_dock_state()            ││
│  │      return self._build_dock_osd(state)                     ││
│  │                                                             ││
│  │  def generate_drone_osd(self) -> dict:                      ││
│  │      state = self.state_manager.get_drone_state()           ││
│  │      return self._build_drone_osd(state)                    ││
│  └─────────────────────────────────────────────────────────────┘│
│  ┌─────────────────────────────────────────────────────────────┐│
│  │  数据增强:                                                   ││
│  │  - 传感器数据添加±1%随机波动                                  ││
│  │  - 时间戳自动更新                                            ││
│  │  - bid/tid生成UUID                                          ││
│  └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
                                   │
                                   │ 生成OSD
                                   ▼
┌─────────────────────────────────────────────────────────────────┐
│                     Scheduler (定时发布)                          │
│  - 以配置频率调用generate_*_osd                                   │
│  - 发布到 thing/product/{gateway_sn}/events                      │
└─────────────────────────────────────────────────────────────────┘
```

### 数据分类与更新策略

| 数据类型 | 示例字段 | 更新策略 |
|---------|---------|---------|
| **动态状态** | cover_state, drone_in_dock, mode_code | 完全由StateManager驱动 |
| **位置数据** | latitude, longitude, height | 由状态驱动，可配置初始位置 |
| **电量数据** | battery.capacity_percent, drone_charge_state | 根据充电/飞行状态缓慢变化 |
| **传感器数据** | temperature, humidity, wind_speed | 基础值+随机波动(±5%) |
| **静态配置** | firmware_version, storage | 配置固定，不变化 |
| **时间戳** | timestamp | 每次生成时更新 |
| **标识符** | bid, tid | 每次生成时生成新UUID |

### 核心数据结构

```python
# 机巢状态
@dataclass
class DockState:
    # 基础状态
    cover_state: int = 0  # 0=关闭, 1=开启
    drone_in_dock: int = 1  # 0=不在, 1=在
    putter_state: int = 0
    emergency_stop_state: int = 0
    
    # 任务状态
    flighttask_step_code: int = 5  # 当前执行步骤
    mode_code: int = 0
    drc_state: int = 0
    
    # 无人机充电
    drone_charge_capacity: int = 100  # 电量百分比
    drone_charge_state: int = 0  # 0=未充电, 1=充电中
    
    # 环境数据（带波动）
    environment_temperature: float = 25.0
    environment_humidity: float = 60.0
    wind_speed: float = 2.0
    
    # 位置
    latitude: float = 23.035792
    longitude: float = 114.230220
    height: float = 13.46

# 无人机状态
@dataclass
class DroneState:
    # 位置
    latitude: float = 23.035841
    longitude: float = 114.230255
    height: float = 27.656
    
    # 姿态
    attitude_head: float = 0.0
    attitude_pitch: float = 0.0
    attitude_roll: float = 0.0
    
    # 电量
    battery_percent: int = 100
    
    # 飞行状态
    mode_code: int = 0
    fly_state: int = 0
    horizontal_speed: float = 0.0
    vertical_speed: float = 0.0
    
    # 相机状态
    gimbal_pitch: float = 0.0
    gimbal_roll: float = 0.0
    gimbal_yaw: float = 0.0
```

### OSD生成实现

```python
class OSDGenerator:
    def __init__(self, state_manager: StateManager, gateway_sn: str):
        self.state_manager = state_manager
        self.gateway_sn = gateway_sn
    
    def generate_dock_osd(self) -> dict:
        state = self.state_manager.get_dock_state()
        return {
            "bid": str(uuid.uuid4()),
            "tid": str(uuid.uuid4()),
            "timestamp": int(time.time() * 1000),
            "gateway": self.gateway_sn,
            "data": {
                "cover_state": state.cover_state,
                "drone_in_dock": state.drone_in_dock,
                "putter_state": state.putter_state,
                "flighttask_step_code": state.flighttask_step_code,
                "mode_code": state.mode_code,
                "drc_state": state.drc_state,
                "drone_charge_state": {
                    "capacity_percent": state.drone_charge_capacity,
                    "state": state.drone_charge_state
                },
                # 传感器数据带波动
                "environment_temperature": self._with_jitter(
                    state.environment_temperature, 0.5
                ),
                "environment_humidity": self._with_jitter(
                    state.environment_humidity, 2.0
                ),
                "wind_speed": self._with_jitter(state.wind_speed, 0.2),
                # 位置数据
                "latitude": state.latitude,
                "longitude": state.longitude,
                "height": state.height,
                # 静态配置
                "firmware_version": "1.6.0.154",
                # ... 其他字段
            }
        }
    
    def _with_jitter(self, value: float, max_delta: float) -> float:
        """添加随机波动"""
        return value + random.uniform(-max_delta, max_delta)
```

### 频率控制

```python
class Scheduler:
    def __init__(self, mqtt_client, osd_generator, frequency: int = 1):
        self.mqtt_client = mqtt_client
        self.osd_generator = osd_generator
        self.frequency = frequency  # Hz
        self.running = False
    
    async def start(self):
        self.running = True
        interval = 1.0 / self.frequency
        
        while self.running:
            start = time.time()
            
            # 生成并发布OSD
            dock_osd = self.osd_generator.generate_dock_osd()
            drone_osd = self.osd_generator.generate_drone_osd()
            
            topic = f"thing/product/{self.gateway_sn}/events"
            self.mqtt_client.publish(topic, json.dumps(dock_osd))
            self.mqtt_client.publish(topic, json.dumps(drone_osd))
            
            # 等待下一个周期
            elapsed = time.time() - start
            await asyncio.sleep(max(0, interval - elapsed))
    
    def stop(self):
        self.running = False
```

---

## ✅ 验证

**需求满足情况:**
- [x] 生成机巢OSD数据
- [x] 生成无人机OSD数据
- [x] 符合Cloud API规范
- [x] 支持1-30Hz频率
- [x] 数据有合理变化模式

**技术可行性:** 高 - 实现简单，状态驱动逻辑清晰

**风险评估:** 低 - OSD生成逻辑独立，易于测试

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 创意阶段结束

