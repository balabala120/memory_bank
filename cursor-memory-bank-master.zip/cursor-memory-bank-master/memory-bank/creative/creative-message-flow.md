# 创意阶段：消息处理流程设计

> **创建日期:** 2026-01-16
> **任务ID:** TASK-001
> **状态:** 完成

---

📌 创意阶段开始：消息处理流程设计
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 1️⃣ 问题

**描述:** 如何处理MQTT消息的完整生命周期，包括消息解析、路由、处理、回复生成？

**需求:**
- 正确解析JSON格式的MQTT消息
- 根据method字段路由到正确的处理器
- 生成标准格式的回复消息
- 处理异常情况不导致程序崩溃
- 支持两种消息通道：services和DRC

**约束:**
- 消息格式遵循Cloud API规范
- 回复需要保持原始bid和tid
- 处理延迟<100ms
- DRC消息需要更高频率处理（5-10Hz）

---

## 2️⃣ 选项

### 选项 A：同步处理模式
所有消息在MQTT回调中同步处理，直接生成回复。

### 选项 B：消息队列模式
MQTT回调将消息放入队列，独立工作线程消费处理。

### 选项 C：协程异步模式
使用asyncio协程处理消息，MQTT回调触发协程执行。

### 选项 D：混合模式
简单消息同步处理，复杂消息异步处理。

---

## 3️⃣ 分析

| 标准 | 选项 A | 选项 B | 选项 C | 选项 D |
|------|--------|--------|--------|--------|
| 实现简单度 | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ |
| 响应速度 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| 并发处理 | ⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| 资源占用 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| Mock场景适用 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |

**关键见解:**
- Mock场景下消息处理逻辑简单，不需要复杂的并发机制
- 同步处理可以保证响应的即时性
- 消息队列增加了不必要的复杂性
- DRC消息（如drone_control）需要快速响应

---

## 4️⃣ 决策

**选定:** 选项 A：同步处理模式

**理由:**
1. **Mock场景简单:** 处理器只需生成模拟回复，无复杂计算
2. **响应最快:** 同步处理避免上下文切换开销
3. **实现简单:** 代码直观，易于调试
4. **符合paho-mqtt模式:** paho-mqtt回调本身就是同步的
5. **资源效率:** 无需额外线程/协程开销

---

## 5️⃣ 实施说明

### 消息处理流程图

```
┌─────────────────────────────────────────────────────────────────┐
│                     MQTT消息到达                                  │
│  Topic: thing/product/{gateway_sn}/services                      │
│     或: thing/product/{gateway_sn}/drc/down                       │
└─────────────────────────────────────────────────────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────┐
│                   1. 消息解析 (mqtt_client.py)                    │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │  try:                                                        ││
│  │      payload = json.loads(message.payload.decode('utf-8'))  ││
│  │  except JSONDecodeError:                                     ││
│  │      logger.error("Invalid JSON message")                    ││
│  │      return  # 忽略无效消息                                   ││
│  └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────┐
│                   2. 消息验证 (message_router.py)                 │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │  验证必要字段:                                                ││
│  │  - bid: 业务ID (必须)                                         ││
│  │  - tid: 事务ID (必须)                                         ││
│  │  - method: 方法名 (必须)                                      ││
│  │  - timestamp: 时间戳 (可选)                                   ││
│  │  - data: 数据载荷 (可选)                                      ││
│  │  - gateway: 网关SN (可选)                                     ││
│  └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────┐
│                   3. 消息路由 (message_router.py)                 │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │  method = payload.get("method")                              ││
│  │  handler = self.handlers.get(method)                         ││
│  │                                                              ││
│  │  if handler:                                                 ││
│  │      response = handler.handle(payload)                      ││
│  │  else:                                                       ││
│  │      response = self.unknown_method_response(payload)        ││
│  └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────┐
│                   4. 业务处理 (handlers/*.py)                     │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │  class FlighttaskPrepareHandler(BaseHandler):                ││
│  │      def handle(self, message: dict) -> dict:                ││
│  │          # 提取业务数据                                        ││
│  │          flight_id = message["data"].get("flight_id")        ││
│  │                                                              ││
│  │          # 更新状态（可选）                                    ││
│  │          self.state_manager.update_task(flight_id)           ││
│  │                                                              ││
│  │          # 生成回复                                           ││
│  │          return self.success_response(message)               ││
│  └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────┐
│                   5. 回复生成 (base_handler.py)                   │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │  def success_response(self, message: dict, output=None):     ││
│  │      return {                                                ││
│  │          "bid": message["bid"],                              ││
│  │          "tid": message["tid"],                              ││
│  │          "timestamp": int(time.time() * 1000),               ││
│  │          "method": message["method"],                        ││
│  │          "gateway": self.gateway_sn,                         ││
│  │          "data": {                                           ││
│  │              "result": 0,                                    ││
│  │              **({"output": output} if output else {})        ││
│  │          }                                                   ││
│  │      }                                                       ││
│  └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────┐
│                   6. 消息发布 (mqtt_client.py)                    │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │  # 根据原始主题确定回复主题                                     ││
│  │  if "services" in original_topic:                            ││
│  │      reply_topic = f"thing/product/{gateway_sn}/services_reply"│
│  │  elif "drc/down" in original_topic:                          ││
│  │      reply_topic = f"thing/product/{gateway_sn}/drc/up"      ││
│  │                                                              ││
│  │  self.client.publish(reply_topic, json.dumps(response))      ││
│  └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

### 错误处理策略

```python
# 错误处理分层
class MessageRouter:
    def process_message(self, topic: str, payload: bytes):
        try:
            # 1. JSON解析错误
            message = json.loads(payload.decode('utf-8'))
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            logger.error(f"Message parse error: {e}")
            return None  # 无法生成回复，忽略
        
        try:
            # 2. 消息验证错误
            self._validate_message(message)
        except ValidationError as e:
            logger.warning(f"Invalid message: {e}")
            return self._error_response(message, error_code=-1)
        
        try:
            # 3. 业务处理错误
            handler = self.handlers.get(message.get("method"))
            if handler:
                return handler.handle(message)
            else:
                return self._unknown_method_response(message)
        except Exception as e:
            logger.error(f"Handler error: {e}")
            return self._error_response(message, error_code=-2)
```

### 消息格式定义

**请求消息格式（下行）:**
```json
{
    "bid": "业务ID (UUID)",
    "tid": "事务ID (UUID)",
    "timestamp": 1715693761421,
    "method": "flighttask_prepare",
    "gateway": "NM1923371013",
    "data": {
        // 方法特定的数据
    }
}
```

**回复消息格式（上行）:**
```json
{
    "bid": "与请求相同的bid",
    "tid": "与请求相同的tid",
    "timestamp": 1715693761468,
    "method": "flighttask_prepare",
    "gateway": "NM1923371013",
    "data": {
        "result": 0,
        "output": {
            // 可选的输出数据
        }
    }
}
```

### 主题映射规则

| 下行主题 | 上行主题 | 用途 |
|---------|---------|------|
| `thing/product/{sn}/services` | `thing/product/{sn}/services_reply` | 普通服务指令 |
| `thing/product/{sn}/drc/down` | `thing/product/{sn}/drc/up` | DRC控制指令 |
| - | `thing/product/{sn}/events` | OSD/事件上报 |

---

## ✅ 验证

**需求满足情况:**
- [x] 正确解析JSON格式消息
- [x] 根据method路由到处理器
- [x] 生成标准格式回复
- [x] 异常处理不崩溃
- [x] 支持services和DRC两种通道

**技术可行性:** 高 - 同步处理模式简单可靠

**风险评估:** 低 - 处理逻辑简单，错误处理完善

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 创意阶段结束

