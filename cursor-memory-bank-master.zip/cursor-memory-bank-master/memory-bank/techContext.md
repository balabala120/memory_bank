# Memory Bank: 技术上下文

## 技术栈

### 编程语言
- **Python 3.x** - 主要开发语言

### 核心依赖
- **paho-mqtt** - MQTT客户端库
- **asyncio** - 异步任务处理（Python标准库）
- **json** - JSON消息处理（Python标准库）
- **datetime** - 时间戳生成（Python标准库）
- **uuid** - UUID生成（Python标准库）

### 开发工具
- Python包管理: pip
- 项目结构: 待规划

## MQTT配置

根据 `docs/mqtt-config.md`:
- **Broker:** emqx-dev-feature.autelrobotics.cn
- **Port:** 31883
- **Username:** "10072"
- **Password:** "7EGT7SPDZ1"

## MQTT主题结构

### 下行指令（订阅）
- `thing/product/{gateway_sn}/services` - 接收指令

### 上行回复（发布）
- `thing/product/{gateway_sn}/services_reply` - 指令回复
- `thing/product/{gateway_sn}/events` - 事件上报（OSD等）

### DRC主题（指令飞行）
- `thing/product/{gateway_sn}/drc/down` - DRC下行
- `thing/product/{gateway_sn}/drc/up` - DRC上行

## 消息格式

### 标准消息结构
```json
{
  "bid": "uuid",
  "tid": "uuid",
  "timestamp": 1234567890,
  "method": "method_name",
  "data": {},
  "gateway": "gateway_sn"
}
```

### OSD消息
- 机巢OSD: 参考 `docs/osd-mqtt-example.md`
- 无人机OSD: 参考 `docs/osd-mqtt-example.md`

## 指令类型

### 航线管理（参考 `docs/fight-task-mqtt-guide.md`）
- flighttask_prepare - 下发任务
- flighttask_execute - 执行任务
- return_home - 一键返航
- flighttask_pause - 航线暂停
- flighttask_recovery - 航线恢复
- flighttask_undo - 取消任务
- return_home_cancel - 取消返航
- flight_task_poi - 兴趣点任务
- cancel_flight_task_poi - 取消兴趣点任务

### 指令飞行（参考 `docs/fly-control-mqtt-guide.md`）
- drc_mode_enter - 进入指令飞行模式
- drc_mode_exit - 退出指令飞行模式
- takeoff_to_point - 一键起飞
- fly_to_point - 飞向目标点
- fly_to_point_stop - 停止飞向目标点
- flight_authority_grab - 飞行控制权抢夺
- payload_authority_grab - 负载控制权抢夺
- drone_control - DRC飞行控制
- drone_emergency_stop - 无人机急停
- heart_beat - DRC心跳

### 负载控制
- camera_photo_take - 单拍
- camera_recording_start - 开始录像
- camera_recording_stop - 停止录像
- camera_screen_drag - 画面拖动控制
- camera_focal_length_set - 变焦
- gimbal_reset - 重置云台
- photo_storage_set - 照片存储设置
- video_storage_set - 视频存储设置
- camera_look_at - Look At
- gimbal_rotate_angle - 云台角度控制
- intelligent_point - 图传打点

## 技术考虑

### 异步处理
- 需要异步处理MQTT消息
- 定时任务需要异步调度

### 状态管理
- 需要维护机巢状态
- 需要维护无人机状态
- 需要维护任务状态

### 消息路由
- 需要根据method字段路由到不同的处理器
- 需要生成标准格式的回复

### 定时任务
- OSD消息需要定时上报
- 需要可配置的上报频率

